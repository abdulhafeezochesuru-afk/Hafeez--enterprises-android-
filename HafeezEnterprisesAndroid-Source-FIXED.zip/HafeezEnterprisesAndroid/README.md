# Hafeez Enterprises Android App

This is the Android Studio project for Hafeez Enterprises.

- Application ID: `com.hafeezenterprises.app`
- App name: Hafeez Enterprises
- Minimum Android version: Android 6.0 (API 23)
- Build task: `:app:assembleDebug`

## Build with GitHub Actions

The workflow in `.github/workflows/android.yml` builds a debug APK and uploads it as an artifact.
